const wordRows = document.querySelectorAll('.word-row');
const guessInput = document.querySelector('.guess-input');
const guessButton = document.querySelector('.guess-button');

const targetWords = generateTargetWords();

guessButton.addEventListener('click', () => {
  const guess = guessInput.value.toLowerCase();
  
  if (guess.length !== 5) {
    alert('De input MOET langer dan 5 zijn');
    return;
  }

  generateTargetWords()
  checkInput(guess);
  
});

function checkInput(guess) {
  for (let i = 0; i < targetWords.length; i++) {
    const targetWord = targetWords[i];
    const wordCells = wordRows[i].querySelectorAll('.word-cell');
    
    if (guess === targetWord) {
      alert('Congrats! -ferman en cees');
    } else {
      updateWordCells(wordCells, guess);
    }
  }
}

function updateWordCells(wordCells, guess) {
  for (let i = 0; i < guess.length; i++) {
    wordCells[i].textContent = guess[i];
  }
}

function generateTargetWords() {
  const words = ['appel', 'broek', 'grape', 'melon'];
  return words;
}
