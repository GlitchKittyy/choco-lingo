function showPopup() {
  var popup = document.getElementById('popup');
  popup.style.display = 'block';
}

function handleResponse(response) {
  if (response) {
    window.location.href = 'medewerker.html';
  } else {
    alert('1');
  }
  hidePopup();
}

function hidePopup() {
  var popup = document.getElementById('popup');
  popup.style.display = 'none';
}

const correctCode = "13790";

function checkPassword() {
  const enteredCode = document.getElementById("passwordInput").value;

  if (enteredCode === correctCode) {
    alert("0");
  } else {
    alert("1");
  }
}